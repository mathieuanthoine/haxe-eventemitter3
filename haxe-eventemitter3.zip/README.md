Haxe externs for EventEmitter 3 (https://github.com/primus/eventemitter3)

## Download & Set Up
EventEmitter 3 on **haxelib**:
```
haxelib install eventemitter3
```